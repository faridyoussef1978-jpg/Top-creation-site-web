
function sendWhatsApp(){
  const f=document.getElementById('orderForm');
  const name=f.name.value.trim(), company=f.company.value.trim(), country=f.country.value, type=f.type.value, details=f.details.value.trim();
  if(!name || !company){alert('Veuillez renseigner votre nom et le nom de votre entreprise.');return;}
  const msg=`Bonjour Top Création Site Web,%0A%0AJe souhaite commander un site web.%0A%0ANom: ${encodeURIComponent(name)}%0AEntreprise: ${encodeURIComponent(company)}%0APays: ${encodeURIComponent(country)}%0AType de site: ${encodeURIComponent(type)}%0ADétails: ${encodeURIComponent(details||'À préciser')}`;
  window.open('https://wa.me/212698153167?text='+msg,'_blank');
}
